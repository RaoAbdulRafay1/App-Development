package com.example.prefsapp;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {

    private static final String PREF_NAME = "user_prefs";

    public static void saveData(Context context, String username, String email, String theme) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("username", username);
        editor.putString("email", email);
        editor.putString("theme", theme);

        editor.apply();
    }

    public static String getUsername(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString("username", "No Username Saved");
    }

    public static String getEmail(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString("email", "No Email Saved");
    }

    public static String getTheme(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString("theme", "Default");
    }

    public static void reset(Context context) {
        SharedPreferences.Editor editor = context
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit();

        editor.clear();
        editor.apply();
    }
}
