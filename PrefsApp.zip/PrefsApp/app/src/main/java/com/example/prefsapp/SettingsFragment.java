package com.example.prefsapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    EditText edtUsername, edtEmail, edtTheme;
    Button btnSave, btnReset;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        edtUsername = view.findViewById(R.id.edtUsername);
        edtEmail = view.findViewById(R.id.edtEmail);
        edtTheme = view.findViewById(R.id.edtTheme);
        btnSave = view.findViewById(R.id.btnSave);
        btnReset = view.findViewById(R.id.btnReset);

        btnSave.setOnClickListener(v -> savePreferences());
        btnReset.setOnClickListener(v -> resetPreferences());

        return view;
    }

    private void savePreferences() {
        String user = edtUsername.getText().toString();
        String email = edtEmail.getText().toString();
        String theme = edtTheme.getText().toString();

        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(email) || TextUtils.isEmpty(theme)) {
            Toast.makeText(getActivity(), "All fields required!", Toast.LENGTH_SHORT).show();
            return;
        }

        PrefsManager.saveData(getActivity(), user, email, theme);

        Toast.makeText(getActivity(), "Preferences Saved!", Toast.LENGTH_SHORT).show();
    }

    private void resetPreferences() {
        PrefsManager.reset(getActivity());
        Toast.makeText(getActivity(), "Preferences Reset!", Toast.LENGTH_SHORT).show();
    }
}
