package com.example.prefsapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    TextView txtUsername, txtEmail, txtTheme;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        txtUsername = view.findViewById(R.id.txtUsername);
        txtEmail = view.findViewById(R.id.txtEmail);
        txtTheme = view.findViewById(R.id.txtTheme);

        loadData();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData(); // updates dynamically when fragment opens again
    }

    private void loadData() {
        txtUsername.setText("Username: " + PrefsManager.getUsername(getActivity()));
        txtEmail.setText("Email: " + PrefsManager.getEmail(getActivity()));
        txtTheme.setText("Theme: " + PrefsManager.getTheme(getActivity()));
    }
}
