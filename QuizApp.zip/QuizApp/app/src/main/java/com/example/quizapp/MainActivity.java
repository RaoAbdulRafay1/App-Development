package com.example.quizapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView display;
    Button submitBtn;
    RadioGroup Q1,Q2,Q3,Q4;
    RadioButton Ans1,Ans2,Ans3,Ans4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Q1 =findViewById(R.id.Q1_radio);
        Q2 =findViewById(R.id.Q2_radio);
        Q3 =findViewById(R.id.Q3_radio);
        Q4 =findViewById(R.id.Q4_radio);
        display =findViewById(R.id.display);
        submitBtn =findViewById(R.id.btn);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int score = 0;
                int id =Q1.getCheckedRadioButtonId();
                Ans1 =findViewById(id);
                id =Q2.getCheckedRadioButtonId();
                Ans2 =findViewById(id);
                id =Q3.getCheckedRadioButtonId();
                Ans3 =findViewById(id);
                id =Q4.getCheckedRadioButtonId();
                Ans4 =findViewById(id);
                if(Ans1.getText().toString().equals("Urdu"))
                {
                    score++;
                }
                if(Ans2.getText().toString().equals("365"))
                {
                    score++;
                }
                if(Ans3.getText().toString().equals("App"))
                {
                    score++;
                }
                if(Ans4.getText().toString().equals("8 billion"))
                {
                    score++;
                }

                display.setText("Your score:" + score + " out of 4");
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}